"""Restaurant performance analytics demonstration."""
